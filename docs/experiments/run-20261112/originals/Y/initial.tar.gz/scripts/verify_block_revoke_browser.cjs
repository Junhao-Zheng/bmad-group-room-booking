// Real browser interaction on isolated synthetic data; never emit credentials.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');
const [origin,credentialsFile,outputDir,executablePath]=process.argv.slice(2);
const users=JSON.parse(fs.readFileSync(credentialsFile,'utf8')).users;
const errorEnvelope=code=>({ok:false,error:{code,message:'合成错误',fields:{},conflicts:[]}});
async function main(){
  const browser=await chromium.launch({headless:true,executablePath});const results=[];
  try{
    for(const width of [1280,390]){
      const context=await browser.newContext({viewport:{width,height:900}}),page=await context.newPage(),errors=[],network=[];
      page.on('pageerror',e=>errors.push(e.name));let posts=0;
      page.on('request',r=>{if(r.method()==='POST'&&r.url().endsWith('/revoke'))posts++;});
      await page.goto(origin+'/login');await page.locator('#username').fill(users[2].username);await page.locator('#password').fill(users[2].password);
      await page.locator('#password').press('Enter');await page.waitForURL(origin+'/');await page.goto(origin+'/admin');
      async function settled(){await page.waitForFunction(()=>!document.querySelector('#revoke-form').hasAttribute('aria-busy'));}
      async function query(){await page.locator('#admin-blocks-submit').click();await page.waitForFunction(()=>!document.querySelector('#admin-blocks-form').hasAttribute('aria-busy'));}
      async function submit(){const wait=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/revoke'));await page.locator('#revoke-submit').click();const response=await wait;const body=await response.json();network.push({path:new URL(response.url()).pathname,status:response.status(),body});await settled();return {status:response.status(),body};}
      async function shot(name){assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await page.locator('#revoke-panel').screenshot({path:path.join(outputDir,`${name}-${width}.png`)});}
      await query();assert.equal(await page.getByRole('button',{name:'选择撤销停用 101',exact:true}).count(),0);
      assert.equal(await page.getByRole('button',{name:'选择撤销停用 110',exact:true}).count(),0);
      const id=width===1280?113:112,unknownId=width===1280?114:115;
      await page.getByRole('button',{name:`选择撤销停用 ${id}`,exact:true}).click();
      assert.equal(await page.locator('#revoke-confirm').isChecked(),false);
      assert.match(await page.locator('#revoke-summary').textContent(),/原停用原因：合成维护 <检查设备>/);
      assert.equal(await page.locator('#revoke-summary img,#revoke-summary script').count(),0);
      await page.locator('#revoke-reason').fill('   ');await page.locator('#revoke-submit').click();assert.equal(posts,0);
      await page.locator('#revoke-confirm').check();const rejected=await submit();assert.equal(rejected.status,400);
      assert.equal(await page.locator('#revoke-reason').inputValue(),'   ');assert.equal(await page.evaluate(()=>document.activeElement.id),'revoke-reason');await shot('validation-error');
      const reason=`  <img src=x onerror="window.revokeXss=1">完成维护 ${width}  `;
      await page.locator('#revoke-reason').fill(reason);await page.locator('#revoke-confirm').check();
      await page.locator('#revoke-reason').fill(reason+'!');assert.equal(await page.locator('#revoke-confirm').isChecked(),false);await page.locator('#revoke-reason').fill(reason);
      await page.route('**/api/admin/blocks/*/revoke',async route=>{const headers=route.request().headers();delete headers['x-csrf-token'];await route.continue({headers});});
      await page.locator('#revoke-confirm').check();assert.equal((await submit()).status,403);assert.equal(await page.locator('#revoke-reason').inputValue(),reason);
      assert.equal(await page.locator('#revoke-relogin').isVisible(),true);await page.unroute('**/api/admin/blocks/*/revoke');
      let release;const gate=new Promise(resolve=>{release=resolve;});
      await page.route('**/api/admin/blocks/*/revoke',async route=>{await gate;await route.continue();});
      await page.locator('#revoke-confirm').check();const pending=submit();
      await page.waitForFunction(()=>document.querySelector('#revoke-form').hasAttribute('aria-busy'));
      assert.equal(await page.locator('#revoke-reason').isDisabled(),true);assert.equal(await page.locator('#block-submit').isDisabled(),true);
      assert.equal(await page.locator('#admin-blocks-submit').isDisabled(),true);assert.match(await page.locator('#revoke-feedback').textContent(),/正在撤销/);await shot('waiting');
      release();const success=await pending;assert.equal(success.status,200);assert.equal(success.body.data.status,'revoked');assert.equal(success.body.data.revoke_reason,reason.trim());
      assert.equal(await page.locator('#revoke-form').isVisible(),false);assert.match(await page.locator('#revoke-summary').textContent(),/首次撤销：.*演示管理员/);
      assert.equal(await page.locator('#revoke-summary img,#revoke-summary script').count(),0);assert.equal(await page.evaluate(()=>window.revokeXss),undefined);await shot('success');
      await page.unroute('**/api/admin/blocks/*/revoke');
      await page.getByRole('button',{name:`选择撤销停用 ${unknownId}`,exact:true}).click();await page.locator('#revoke-reason').fill('首次撤销原因');await page.locator('#revoke-confirm').check();
      let committed;
      await page.route('**/api/admin/blocks/*/revoke',async route=>{const response=await route.fetch();assert.equal(response.status(),200);committed=(await response.json()).data;await route.abort();});
      const previousPosts=posts;await page.locator('#revoke-submit').click();
      await page.waitForFunction(()=>document.querySelector('#revoke-feedback').textContent.includes('未能确认'));await settled();
      assert.equal(await page.locator('#revoke-reason').inputValue(),'首次撤销原因');assert.equal(await page.locator('#revoke-confirm').isChecked(),false);assert.equal(posts,previousPosts+1);await shot('unknown-outcome');
      await page.unroute('**/api/admin/blocks/*/revoke');await page.locator('#revoke-reason').fill('后续不同撤销原因');await page.locator('#revoke-confirm').check();
      const repeated=await submit();assert.equal(repeated.status,200);assert.deepEqual(repeated.body.data,committed);assert.match(await page.locator('#revoke-summary').textContent(),/撤销原因：首次撤销原因/);
      await page.getByRole('button',{name:'选择撤销停用 108',exact:true}).click();await page.locator('#revoke-reason').fill('失效身份仍保留草稿');await page.locator('#revoke-confirm').check();
      const identity=(await (await context.request.get(origin+'/api/me')).json()).data;
      assert.equal((await context.request.post(origin+'/api/logout',{data:{},headers:{Origin:origin,'X-CSRF-Token':identity.csrf_token}})).status(),200);
      assert.equal((await submit()).status,401);assert.equal(await page.locator('#revoke-reason').inputValue(),'失效身份仍保留草稿');assert.equal(await page.locator('#revoke-submit').isDisabled(),true);
      assert.equal(await page.locator('#admin-blocks-items > li').count(),0);await shot('expired-session');
      assert.deepEqual(errors,[]);fs.writeFileSync(path.join(outputDir,`network-${width}.json`),JSON.stringify(network,null,2));
      results.push({width,validation:true,confirmation:true,csrf:true,waiting:true,success:true,unknown_then_idempotent_retry:true,expired_session:true,safe_text:true,no_horizontal_overflow:true,page_errors:errors});
      await context.close();
    }
  }finally{await browser.close();}
  process.stdout.write(JSON.stringify({result:'PASS',viewports:results}));
}
main().catch(error=>{process.stderr.write(error.stack+'\n');process.exitCode=1;});
