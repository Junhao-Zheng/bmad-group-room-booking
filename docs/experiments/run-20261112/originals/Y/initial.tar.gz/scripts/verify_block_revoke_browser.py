"""Run desktop and mobile revocation interactions against a real local server."""
import argparse
import json
import os
from pathlib import Path
import secrets
import subprocess
import tempfile

from booking_app import ROOT, db
from scripts.init_demo import DEMO_IDENTITIES, seed_users
from scripts.verify_block_revoke_http import snapshot, source_hashes
from scripts.verify_create_booking_http import BookingServer, FixedClock
from scripts.verify_room_management_http import facts
from tests.schedule_fixtures import insert_record, seed_schedule_fixture


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser-executable',type=Path,default=Path('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'))
    parser.add_argument('--output-dir',type=Path,default=ROOT/'work/block-revoke-browser')
    args=parser.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    target=args.output_dir/'browser-result.json'
    target.write_text(json.dumps(dict(result='INCOMPLETE',completed=False)))
    with tempfile.TemporaryDirectory(prefix='revoke-browser-',dir=ROOT/'work') as directory:
        temporary=Path(directory);database=temporary/'test.sqlite3'
        users=[dict(username=u,display_name=d,role=r,password=secrets.token_urlsafe(24)) for u,d,r in DEMO_IDENTITIES]
        credentials=temporary/'credentials.json';credentials.touch(mode=0o600);credentials.write_text(json.dumps(dict(users=users)))
        seed_users(database,users,FixedClock());seed_schedule_fixture(database)
        with db.write_transaction(database) as conn:
            for record,room,start,end in [(112,30,'09:00','11:00'),(113,20,'12:00','14:00'),(114,30,'12:00','13:00'),(115,20,'14:00','15:00')]:
                insert_record(conn,record,room,'2026-11-12T'+start,'2026-11-12T'+end,kind='block')
        before=facts(database);server=BookingServer(database)
        try:
            server.start()
            process=subprocess.run(['node',str(ROOT/'scripts/verify_block_revoke_browser.cjs'),server.origin,str(credentials),str(args.output_dir),str(args.browser_executable)],
                cwd=ROOT,env=dict(os.environ,NODE_PATH=str(ROOT/'work/browser-tools/node_modules')),capture_output=True,text=True,timeout=180)
            if process.returncode:
                print(process.stderr);raise RuntimeError('Browser verification failed')
            result=json.loads(process.stdout);after=facts(database)
            changed={112,113,114,115}
            assert [r for r in before['reservations'] if r['id'] not in changed]==[r for r in after['reservations'] if r['id'] not in changed]
            assert after['occupancy_slots']==[r for r in before['occupancy_slots'] if r['reservation_id'] not in changed]
            assert len(after['audit_events'])==4
            for row in after['reservations']:
                if row['id'] not in changed: continue
                assert row['cancelled_by']==3 and row['cancelled_at'] is not None
                assert len([event for event in after['audit_events'] if event['target_id']==row['id'] and event['action']=='block.revoked'])==1
            (args.output_dir/'database-facts.json').write_text(json.dumps(dict(before=before,after=after),ensure_ascii=False,indent=2))
            report=result|dict(completed=True,storage_verified=True,revocations=4,revoke_audits=4,other_records_preserved=True,source_sha256=source_hashes())
            target.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(result|dict(storage_verified=True),ensure_ascii=False,indent=2))
        finally:
            server.stop()


if __name__=='__main__':
    main()
